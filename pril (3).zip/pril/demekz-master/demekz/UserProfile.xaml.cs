﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для UserProfile.xaml
    /// </summary>
    public partial class UserProfile : Page
    {
        public UserProfile()
        {
            InitializeComponent();
            PhotoPep();
            InfoProfile();
        }
        public void InfoProfile()
        {
             F_name.Content = Manager.CurrentUser.first_name;
            L_name.Content= Manager.CurrentUser.last_name;
            Patr.Content = Manager.CurrentUser.patronymic;
            Birth.Content = Manager.CurrentUser.date_birth;
            Phone.Content = Manager.CurrentUser.telephone;
            Gender.Content = Manager.CurrentUser.gender;

        }
        private void PhotoPep()
        {
            MemoryStream byteStream = new MemoryStream(Manager.CurrentUser.photo);
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.StreamSource = byteStream;
            image.EndInit();
            PhotoPPPP.Source = image;
        }
        private void btnToBack(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }
        
    }
}
