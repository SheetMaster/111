﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Page
    {
        int wrongLog = 0;
        
        public Auth()
        {
            InitializeComponent();

            
        }

        private void btnToMainPage(object sender, RoutedEventArgs e)
        {
            var login = LoginText.Text;
            var password = PasswordText.Text;
            List<User> users = pepeEntities.GetContext().User.Where(p => p.mail == login && p.password == password).ToList();
            User currentUser = pepeEntities.GetContext().User.FirstOrDefault(p => p.mail == login && p.password == password);
            Manager.CurrentUser = currentUser;
            if (users.Count>=1)
            {
                MessageBox.Show($"Успешный вход!");
                NavigateToMainPage();
            }
            else
            {
                wrongLog ++;
                MessageBox.Show($"Осталось попыток: {wrongLog}");
            }
            if (wrongLog == 3) Manager.MainFrame.Navigate(new Captcha());
        }
        private void NavigateToMainPage()
        {
            Manager.MainFrame.Navigate(new MainPage());

        }

       
    }
}
