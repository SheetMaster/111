﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            UpdateGreeting();
            //ImportPhoto();
            DGridMain.ItemsSource = pepeEntities.GetContext().Event.ToList();
            Manager.MainFrame = Pepega;
        }

        private void btnToAuth(object sender, RoutedEventArgs e)
        {
            AuthButton.Visibility = Visibility.Hidden;
            LabelGo.Visibility = Visibility.Hidden;
            DGridMain.Visibility = Visibility.Hidden;
            Manager.MainFrame.Navigate(new Auth());
        }
        private void UpdateGreeting()
        {
            int currentHour = DateTime.Now.Hour;
            if (currentHour >=0 && currentHour<12) 
            {
                LabelGo.Content = "Доброе утро!";
            }
            else if (currentHour >=12 && currentHour <20)
            {
                LabelGo.Content = "Добрый день!";
            }
            else
            {
                LabelGo.Content = "Добрый вечер!";
            }

        }
        private void ImportPhoto()
        {
            var images = Directory.GetFiles(@"C:\Users\isp11\OneDrive\Рабочий стол\дэ свежее\Ресурсы\Организаторы_import");

            var events = pepeEntities.GetContext().User.Where(u => u.id_role == 1).ToList();
            for (int i = 0; i < events.Count; i++)
            {
                try
                {
                    events[i].photo = File.ReadAllBytes(images[i % images.Length]);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
                pepeEntities.GetContext().SaveChanges();
            }
        }


    }
}
