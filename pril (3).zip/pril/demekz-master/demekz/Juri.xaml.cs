﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для Juri.xaml
    /// </summary>
    public partial class Juri : Page
    {
        public Juri()
        {
            InitializeComponent();
            DGridJuri.ItemsSource = pepeEntities.GetContext().User.Where(q => q.id_role == 2).ToList();
           //ImportPhoto();
        }

        private void btnToAdd(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddPage());
        }

        private void btnToBack(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();

        }
        private void ImportPhoto()
        {
            var images = Directory.GetFiles(@"C:\Users\isp11\OneDrive\Рабочий стол\дэ свежее\Ресурсы\Жюри_import");

            var events = pepeEntities.GetContext().User.Where(u => u.id_role == 2).ToList();
            for (int i = 0; i < events.Count; i++)
            {
                try
                {
                    events[i].photo = File.ReadAllBytes(images[i % images.Length]);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
                pepeEntities.GetContext().SaveChanges();
            }
        }
    }
}
